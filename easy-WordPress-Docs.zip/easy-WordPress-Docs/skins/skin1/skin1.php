<?php

function add_custom_fonts() {
	echo "<link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,400italic,600,700,700italic|Roboto+Slab:300,700' rel='stylesheet' type='text/css'>";
}
add_action('wp_head','add_custom_fonts');

?>