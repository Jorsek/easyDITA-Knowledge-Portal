/*------------------------------------------------------------
  icons.js
 
  Places icons for certain DITA elements
------------------------------------------------------------ */

(function($){
  
  let $notes = $('.topic-note'),
      $defaultNotes = $('.topic-note.note'),
      $cautionNotes = $('.topic-note.caution');
      
  if($notes) {
    $notes.wrap('<div class="note-wrap"></div>');
  }
      
  if($defaultNotes) {
    $defaultNotes.before('<i class="note-icon note-default"></i>');
  }
  
  if($cautionNotes) {
    $cautionNotes.before('<i class="note-icon note-caution"></i>');
  }
    
})(jQuery);

//  if $note
//    wrap note in parent div with class name 'note-wrap'
//    put <i> before note
//  apply flex property on 'note-wrap'
  
