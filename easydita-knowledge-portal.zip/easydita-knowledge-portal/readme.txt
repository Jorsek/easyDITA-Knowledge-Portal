=== easyDITA Knowledge Portal ===

Contributors: Jorsek LLC
Tags: custom-header, dark, light, one-column, two-columns, left-sidebar, fluid-layout, responsive-layout, custom-colors, custom-menu, featured-images, theme-options, translation-ready, threaded-comments

== Description ==

This theme has been designed by Jorsek LLC for use with content published from easyDITA. It is best used for displaying documentation content such as User Guides, Tutorials, and FAQs.

== Installation ==
	
1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.
